/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2004 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

package com.adobe.livecycle.samples;


import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.nio.channels.FileChannel;

import java.io.BufferedInputStream;
import java.net.URL;
import java.net.URLConnection;

public class SampleUtil
{
/**
 * Return a array of file name srings given a path to a directory
 *  *
 * @param file_path required; Full path name of the directory
 *
 * @throws Exception
 */
/*
 public static String[] listFiles(String file_path) throws Exception
 {
  String[] flist = null;
  try
  {
  if (file_path != null)
  {
    File f = new File(file_path);

    if (f.isDirectory())
    {
    flist = f.list();
    }

  }
  else
  {
    flist = new String[0];
  }
  }
  catch (Exception e)
  {
  throw e;
  }
  return flist;
 }
*/


/**
 * Read a file in as a byte array
 *  *
 * @param file_path required; Full path name of the file to read
 *
 * @throws Exception
 */
  public static byte[] getBytes(String file_path) throws IOException
  {
    FileInputStream s = new FileInputStream(file_path);
    byte[] data = new byte[s.available()];
    s.read(data);
    s.close();
    return data;
  }

  /**
   * Get a DOM object for an xml file
   *
   * @param xmlFilePath required; Full path name of the xml file
   *
   * @throws Exception
   */
/*
  public static Document getDOM(String xmlFilePath) throws Exception
  {
  byte[] b = null;
  b = getByteArray(xmlFilePath);
  if (b != null)
     return getDOM(b);
  else
     return null;
  }
*/

  /**
   * Get a DOM object for an xml file
   *
   * @param xmlData required; The xml file as a byte array
   *
   * @throws Exception
   */
/*
  public static Document getDOM(byte[]xmlData) throws Exception
  {
  try
  {
    DOMParser oParser = new DOMParser();
    InputSource oInputSource = new InputSource (new ByteArrayInputStream (xmlData));
    oParser.parse (oInputSource);
    return oParser.getDocument();

  }
  catch (Exception e)
  {
    throw e;
  }
  }
*/

  /**
   * Set a value associated with an xml tag
   *
   * @param tag required; name of the tag
   * @param value reuired; string; value to be given to the tag
   * @param oDOM required; DOM object for the xml file
   *
   * @throws Exception
   */
/*
  public static void setElementValue(String tag, String theData, Document oDOM) throws Exception
  {
    try
  {
    NodeList oList = oDOM.getElementsByTagName(tag);
    if (oList.getLength() > 0)
    {
    NodeList oChildNodes = oList.item(0).getChildNodes();
    for (int j = 0; j < oChildNodes.getLength(); j++)
    {
      Node oItem = oChildNodes.item(j);
      if (oItem.getNodeType() == Node.TEXT_NODE)
      {
      oItem.setNodeValue(theData);
      break;
      }
    }
    }

  }
  catch (Exception e)
  {
    throw new Exception ("Can't get elements. Failure in getElementValue");
  }
  }
*/

  /**
   * Update the tag value in an xml file
   *
   * @param xmldataequired; byte[] of xml data
   * @param tag required; name of the tag
   * @param value; String specifying the value
   *
   * @return byte array of updated xml data
   *
   * @throws Exception
   */
/*
  public static byte[] updateXML(byte[] xmldata, String tag, String value) throws Exception
  {
  try
  {
  Document dom = getDOM(xmldata);
  setElementValue(tag, value, dom);

  return domToXML(dom);
  }
  catch (Exception e)
  {
    throw new Exception("Exception in MSUtil.updateXML: " + e.toString());
  }

  }
*/

  /**
   * Get a value associated with an xml tag
   *
   * @param tag required; name of the tag
   * @param oDOM required; DOM object for the xml file
   *
   * @throws Exception
   */
/*
  public static String getElementValue(String tag, Document oDOM) throws Exception
  {
  String theData = "";

  try
  {
    NodeList oList = oDOM.getElementsByTagName(tag);
    if (oList.getLength() > 0)
    {
    NodeList oChildNodes = oList.item(0).getChildNodes();
    for (int j = 0; j < oChildNodes.getLength(); j++)
    {
      Node oItem = oChildNodes.item(j);
      if (oItem.getNodeType() == Node.TEXT_NODE)
      {
      theData += oItem.getNodeValue();
      break;
      }
    }
    }
    return theData;
  }
  catch (Exception e)
  {
    throw new Exception ("Can't get elements. Failure in getElementValue");
  }
  }
*/
  /**
   * write the content of a DOM to a byte array.
   *
   * @param dom required; the document object model
   *
   * @returns xml byte array byte[]
   */
/*
  public static byte[] domToXML(Document dom ) throws Exception
  {
  ByteArrayOutputStream xmlBytes = new ByteArrayOutputStream();
  DOMSource dom_source = new DOMSource(dom);
  StreamResult result = new StreamResult(xmlBytes);

  TransformerFactory tf = TransformerFactory.newInstance();
  Transformer transformer = tf.newTransformer();

  transformer.transform(dom_source, result);

  return xmlBytes.toByteArray();
  }
*/


  /**
   * write the content from a byte array to the specified file. If the file
   * already exists, create a new name by appending an ordinal.
   *
   * @param theBytes required; an byte array
   * @param filePath required; a String for the file path
   * @param fileExtension optional; the file extension
   *
   * @returns filename Sring
   */
/*
  public static String writeArray(byte[] theBytes, String filePath, String fileExtension)
  {
  boolean retVal=false;
  byte[] buffer = new byte[10240];
  String fn = filePath;

  try
  {
    File f = new File(fn + 0 + "." +  fileExtension);
    for (int k=0; f.exists(); k++) {
    f = new File(fn + k + "." + fileExtension);
    }
    ByteArrayInputStream is = new ByteArrayInputStream(theBytes);
    copyFile(is, f.getPath());
  }
  catch (Exception e)
  {
    fn = null;
  }
   return fn;
  }
*/
  /**
   * write the content from InputStream into the specified file
   *
   * @param is required; an InputStream object
   * @param filePath required; an String for the file path
   *
   * @throws Exception
   */
  public static boolean saveStream(InputStream is, String filePath)
    throws Exception
  {
  boolean retVal=false;
  byte[] buffer = new byte[10240];
  FileOutputStream outStream = null;
  try
  {
    outStream = new FileOutputStream(filePath);
    int len=0;
    while (true)
    {
    len = is.read(buffer);
    if (len == -1)
      break;
    outStream.write(buffer, 0, len);
    }
    outStream.close();
    retVal = true;
  }

  catch (IOException io)
  {
    throw new Exception(
      "writing the array of bytes into the file "+ filePath +
    " failed in copyFile");
  }
  return retVal;
  }

  /**
   * write the content from InputStream into the specified file
   *
   * @param is required; an InputStream object
   * @param filePath required; an String for the file path
   *
   * @throws Exception
   */
  public static boolean saveBytes(byte[] bytes, String filePath)
    throws Exception
  {
  InputStream is = new ByteArrayInputStream(bytes);
  boolean retVal=false;
  byte[] buffer = new byte[10240];
  FileOutputStream outStream = null;
  try
  {
    outStream = new FileOutputStream(filePath);
    int len=0;
    while (true)
    {
    len = is.read(buffer);
    if (len == -1)
      break;
    outStream.write(buffer, 0, len);
    }
    outStream.close();
    retVal = true;
  }
  catch (IOException io)
  {
    throw new Exception(
      "writing the array of bytes into the file "+ filePath +
    " failed in copyFile");
  }
  return retVal;
  }

  /**
   * Copy a file.
   *
   *
   * @param src required: source file
   * @param dst required; destination file
   *
   * @throws Exception
   */
  public static void copyFile(String src, String dst) throws IOException
  {
     FileChannel from = new FileInputStream(src).getChannel();
     FileChannel to = new FileOutputStream(dst).getChannel();
     to.transferFrom(from, 0, from.size());
     from.close();
     to.close();
   }

  // Used to retrieve a resource from a URL via a stream.
  public static byte[] getBytes (URL config) throws IOException
  {
    URLConnection oConnect = config.openConnection();
    // Turn off any caching strategy.
    oConnect.setUseCaches(false);
    BufferedInputStream oStream = new BufferedInputStream (oConnect.getInputStream());

    int n = 0;
    int nContentLength = 0;
    int  nBlkSize = 1024*64;
    byte[] cContent = new byte[0];
    byte[] cTemp = new byte[nBlkSize];


    // Build byteArray from the inputStream.
    while ((n = oStream.read (cTemp, 0, nBlkSize)) > 0)
    {
      // Allocate new mem.
      byte[] cBuf = new byte[n + nContentLength];
      // Copy old, then copy new.
      System.arraycopy(cContent, 0, cBuf, 0, nContentLength);
      System.arraycopy(cTemp, 0, cBuf, nContentLength, n);

      cContent = cBuf;
      nContentLength += n;
    }
    oStream.close();

    return resizeByteArray( cContent, nContentLength );
  }

  /**
  * Reallocates an array with a new size, and copies the contents
  * of the old array to the new array.
  * @param oldArray  the old array, to be reallocated.
  * @param newSize   the new array size.
  * @return    A new array with the same contents.
  */
  private static byte[] resizeByteArray(byte[] oldArray, int newSize)
  {
    int oldSize = oldArray.length;
    byte[] newArray = new byte[newSize];
    int preserveLength = Math.min(oldSize, newSize);
    if (preserveLength > 0)
    {
      System.arraycopy(oldArray, 0, newArray, 0, preserveLength);
    }
    return newArray;
  }
}
