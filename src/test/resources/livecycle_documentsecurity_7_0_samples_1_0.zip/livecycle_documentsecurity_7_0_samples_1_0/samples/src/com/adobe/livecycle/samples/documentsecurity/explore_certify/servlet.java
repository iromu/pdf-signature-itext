package com.adobe.livecycle.samples.documentsecurity.explore_certify;

/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2004-2005 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

import javax.rmi.PortableRemoteObject;
import javax.naming.InitialContext;
import javax.transaction.UserTransaction;

import com.adobe.service.ConnectionFactory;
import com.adobe.service.DataBuffer;
import com.adobe.service.DataManagerHelper;
import com.adobe.service.DataManager;

import com.adobe.document.pdf.Credential;
import com.adobe.document.pdf.PDFDocument;
import com.adobe.document.pdf.PDFFactory;
import com.adobe.document.pdf.PDFFactoryHelper;
import com.adobe.document.pdf.SignatureField;
import com.adobe.document.pdf.SignaturePermissions;

import com.adobe.livecycle.samples.SessionTempFile;
import com.adobe.devtech.jsp.MultipartForm;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletException;
import javax.servlet.ServletContext;
import javax.servlet.RequestDispatcher;

public class servlet extends HttpServlet
{
  public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
  {

    //
    // Get the web context path for this sample
    //

    String samplePath = request.getServletPath();
    samplePath = samplePath.substring(0, samplePath.lastIndexOf("/"));
    try
    {               /* START */
      //
      // Get the PDF document uploaded
      //

      MultipartForm form = new MultipartForm(request);
      InputStream is = form.getFileData("pdf");

      //
      // The Adobe Document Security server needs a filepath for the
      // PDF to certify. We must save the uploaded document into a
      // temporary file. Here we save the uploaded file.
      //

      SessionTempFile stf = new SessionTempFile("document", ".pdf");
      OutputStream outstream = new FileOutputStream(stf.getFile().getPath());
      byte[] buffer = new byte[10240];
      int len = 0;
      while (true)
      {
        len = is.read(buffer);
        if (len == -1)
          break;
        outstream.write(buffer, 0, len);
      }
      outstream.close();

      //
      // Get the signature alias/password from the user input. We will
      // use them to create a Credential object.
      //

      String alias, password;
      String type = form.getString("type");
      if (type.equals("sample"))
      {
        alias = form.getString("aliaslist");
        password = "password";
      }
      else
      {
        alias = form.getString("alias");
        password = form.getString("password");
      }

      //
      // Create SignaturePermissions object from the user input. We
      // will use this object in the certify method call below.
      //

      SignaturePermissions sigPermission = SignaturePermissions.FORM_FIELDS;
      int permission = form.getInt("permission");
      if (permission == 0)
        sigPermission = SignaturePermissions.NO_CHANGES;
      else if (permission == 1)
        sigPermission = SignaturePermissions.FORM_FIELDS;
      else if (permission == 2)
        sigPermission = SignaturePermissions.FORM_FIELDS_AND_COMMENTS;

      //
      // Get the remaining form parameters
      //

      String reason = form.getString("reason");
      String location = form.getString("location");
      String contact = form.getString("contact");
      String legal = form.getString("legal");
      boolean lock = form.getString("lock").equals("true")? true:false;

      Object o;
      ConnectionFactory connectionFactory;
      InitialContext namingContext = new InitialContext();

      //
      // Start a transaction so the server will know when it can clean
      // up after itself.
      //

      UserTransaction transaction = (UserTransaction) namingContext.lookup
        ("java:comp/UserTransaction");
      transaction.begin();

      try
      {

        //
        // Create a PDF manipulation object. We will use this object
        // to certify the PDF document.
        //

        o = namingContext.lookup("PDFManipulation");
        connectionFactory = (ConnectionFactory) PortableRemoteObject.narrow
          (o,ConnectionFactory.class);
        PDFFactory pdfFactory = PDFFactoryHelper.narrow
          ((org.omg.CORBA.Object)connectionFactory.getConnection());

        //
        // Create a data manager object. The data manager creates the
        // objects that we need to pass to the PDF manipulation object.
        //

        o = namingContext.lookup("DataManagerService");
        connectionFactory = (ConnectionFactory) PortableRemoteObject.narrow
          (o,ConnectionFactory.class);
        DataManager dataManager = DataManagerHelper.narrow
          ((org.omg.CORBA.Object)connectionFactory.getConnection());

        //
        // Read the PDF document stored in the temporary file into
        // the DataBuffer that we need for the PDF manipulation object
        // to work with.
        //

        DataBuffer pdfFile =
          dataManager.createFileDataBuffer(stf.getFile().getPath());
        PDFDocument pdfDoc = pdfFactory.openPDF(pdfFile);

        //
        // Add an invisible signature field to the document for the
        // certifying signature.
        //

        SignatureField sigField = pdfDoc.addInvisibleSignatureField();
        String sigName = sigField.getFieldName();

        //
        // Certify the document by signing the signature field
        //

        Credential credential = new Credential();
        credential.alias = alias;
        credential.password = password.getBytes("UTF-8");
        pdfDoc.certify
          (
            credential,
            sigName,
            reason,
            location,
            contact,
            sigPermission,
            lock,
            legal
          );

        //
        // Get the modified PDF document.
        //

        DataBuffer result = pdfDoc.save();

        //
        // Here we create a temporary file in the form of a SessionTempFile.
        // The SessionTempFile object creates a temporary file and
        // implements a session listener to erase the file when the
        // session terminates. The temporary file will hold the certified
        // document. so we can refer to it from the next page.
        //

        stf = new SessionTempFile("step1", ".pdf");
        HttpSession session = request.getSession();
        session.setAttribute(samplePath + "/step1.pdf", stf);
        OutputStream os = new FileOutputStream(stf.getFile());
        os.write(result.getBytes(0L, result.getBufLength()));
        os.close();
      }
      catch (Exception error)
      {
        //
        // terminate the transaction when there is an exception
        //
        transaction.rollback();
        throw error;
      }

      //
      // Let the server clean up its temporary storage.
      //

      transaction.commit();

      //
      // Redirect the browser to the next page.
      //

      response.sendRedirect("finished.jsp");
      return;
    }               /* STOP */
    catch (Exception error)
    {

      //
      // If we encounter any unexpected errors, forward the server
      // to  an error notification page where we can display the error
      // and a stack trace. This will save you having to search through
      // server log files to find out what went wrong when you start
      // to experiment with this code.
      //

      request.setAttribute("error", error);
      ServletContext context = getServletContext();
      RequestDispatcher dispatcher =
        context.getRequestDispatcher("/common/error.jsp");
      dispatcher.forward(request, response);
      return;
    }
  }
}
