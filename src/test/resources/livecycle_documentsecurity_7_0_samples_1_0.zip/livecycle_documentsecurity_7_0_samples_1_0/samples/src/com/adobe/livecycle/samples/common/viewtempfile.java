package com.adobe.livecycle.samples.common;

import com.adobe.livecycle.samples.SessionTempFile;

import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.IOException;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*******************************************************************
 *
 * Return a temporary file to the browser. The SessionTempFile
 * object for the file to return is obtained from the session
 * using the named attribute. If the session variable is not
 * defined, nothing is returned.
 *
 *******************************************************************/

public class viewtempfile extends HttpServlet
{
  public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException
  {
    //
    // Get the sample path and temporary file id and temporary file.
    //

    HttpSession session = request.getSession();
    String id = request.getParameter("id");
    if (id == null)
      return;
    SessionTempFile stf = (SessionTempFile) session.getAttribute(id);
    if (stf == null)
      return;

    //
    // Return the contents of the temporary file to the browser.
    //

    String src = stf.getFile().getPath();
    OutputStream os = response.getOutputStream();
    response.setContentType(stf.getContentType());
    FileInputStream fis = new FileInputStream(src);
    byte[] buf = new byte[1024];
    while (true)
    {
      int count = fis.read(buf);
      if (count == -1)
        break;
      os.write(buf, 0, count);
    }
    os.flush();
    fis.close();
  }
}
