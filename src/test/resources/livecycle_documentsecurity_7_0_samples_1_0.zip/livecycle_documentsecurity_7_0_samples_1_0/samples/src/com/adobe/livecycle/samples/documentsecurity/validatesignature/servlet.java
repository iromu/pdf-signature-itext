package com.adobe.livecycle.samples.documentsecurity.validatesignature;

/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2004 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

import javax.rmi.PortableRemoteObject;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.transaction.UserTransaction;

import com.adobe.service.ConnectionFactory;
import com.adobe.service.DataBuffer;
import com.adobe.service.DataManagerHelper;
import com.adobe.service.DataManager;

import com.adobe.document.pdf.NotSigned;
import com.adobe.document.pdf.PDFDocument;
import com.adobe.document.pdf.PDFFactory;
import com.adobe.document.pdf.PDFFactoryHelper;
import com.adobe.document.pdf.SignatureField;
import com.adobe.document.pdf.SignatureFieldStatus;
import com.adobe.document.pdf.SignatureInfo;

import com.adobe.livecycle.samples.SessionTempFile;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletException;
import javax.servlet.ServletContext;
import javax.servlet.RequestDispatcher;
import java.io.IOException;

public class servlet extends HttpServlet
{
  public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
  {

    //
    // Get the web context path for this sample
    //

    String samplePath = request.getServletPath();
    samplePath = samplePath.substring(0, samplePath.lastIndexOf("/"));
    try
    {               /* START */
      Object o;
      ConnectionFactory connectionFactory;
      InitialContext namingContext = new InitialContext();

      //
      // Start a transaction so the server will know when it can clean
      // up after itself.
      //

      UserTransaction transaction = (UserTransaction) namingContext.lookup
        ("java:comp/UserTransaction");
      transaction.begin();

      try
      {
        //
        // Create PDF manipulation object. We will use this object
        // to extract and validate signatures.
        //

        o = namingContext.lookup("PDFManipulation");
        connectionFactory = (ConnectionFactory) PortableRemoteObject.narrow
          (o,ConnectionFactory.class);
        PDFFactory pdfFactory = PDFFactoryHelper.narrow
          ((org.omg.CORBA.Object)connectionFactory.getConnection());

        //
        // Create a data manager object. The data manager creates the
        // objects that we need to pass to the PDF manipulation object.
        //

        o = namingContext.lookup("DataManagerService");
        connectionFactory = (ConnectionFactory) PortableRemoteObject.narrow
          (o,ConnectionFactory.class);
        DataManager dataManager = DataManagerHelper.narrow
          ((org.omg.CORBA.Object)connectionFactory.getConnection());

        //
        // Read the PDF document into the DataBuffer that we need for
        // the PDF manipulation object to work with.
        //

        String contentUrl =
          request.getScheme() + "://" +
          request.getServerName() + ":" +
          request.getServerPort() +
          request.getContextPath() +
          samplePath;
        DataBuffer pdfFile = dataManager.createFileDataBufferFromUrl
          (contentUrl + "/signed.pdf");
        PDFDocument pdfDoc = pdfFactory.openPDF(pdfFile);

        //
        // Here we create a temporary file in the form of a SessionTempFile.
        // The SessionTempFile object creates a temporary file and
        // implements a session listener to erase the file when the
        // session terminates.The temporary file will hold the signature
        // validation results so we can refer to them from the next
        // page.
        //

        HttpSession session = request.getSession();
        SessionTempFile stf = new SessionTempFile("step1", ".txt");
        session.setAttribute(samplePath + "/step1.txt", stf);
        PrintWriter pw = new PrintWriter(new FileWriter(stf.getFile()));

        //
        // Extract the signature field info for all signature fields
        // in the document and capture the results of the validation
        // that is automatically done when the field is extracted.
        //

        SignatureField[] signatureFields = pdfDoc.getSignatureFieldList();
        for (int i = 0; i < signatureFields.length; i++)
        {
          String fieldName = signatureFields[i].getFieldName();
          String signer;
          String signatureStatus;
          try
          {
            SignatureInfo signatureInfo = signatureFields[i].getSignatureInfo();
            signer = signatureInfo.signer;
            SignatureFieldStatus status = signatureInfo.status;
            if (status == SignatureFieldStatus.VALID_SIGNATURE)
              signatureStatus = "VALID_SIGNATURE";
            else
              if (status == SignatureFieldStatus.INVALID_SIGNATURE)
                signatureStatus = "INVALID_SIGNATURE";
              else
                if (status == SignatureFieldStatus.IDENTITY_UNVERIFIABLE)
                  signatureStatus = "IDENTITY_UNVERIFIABLE";
                else
                  if (status == SignatureFieldStatus.STATUS_UNKNOWN)
                    signatureStatus = "STATUS_UNKNOWN";
                  else
                    signatureStatus="Not defined";
          }
          catch (NotSigned error)
          {
            signer = "Not signed";
            signatureStatus = "";
          }
          pw.print("Field=" + fieldName);
          pw.print(" Signer=" + signer);
          pw.print(" Status=" + signatureStatus);
          pw.println();
        }
      pw.close();
      }
      catch (Exception error)
      {
        //
        // terminate the transaction when there is an exception
        //
        transaction.rollback();
        throw error;
      }

      //
      // Let the server clean up its temporary storage.
      //

      transaction.commit();

      //
      // Redirect the browser to the next page.
      //

      response.sendRedirect("finished.jsp");
      return;
    }               /* STOP */
    catch (Exception error)
    {

      //
      // If we encounter any unexpected errors, forward the server
      // to  an error notification page where we can display the error
      // and a stack trace. This will save you having to search through
      // server log files to find out what went wrong when you start
      // to experiment with this code.
      //

      request.setAttribute("error", error);
      ServletContext context = getServletContext();
      RequestDispatcher dispatcher =
        context.getRequestDispatcher("/common/error.jsp");
      dispatcher.forward(request, response);
      return;
    }
  }
}
