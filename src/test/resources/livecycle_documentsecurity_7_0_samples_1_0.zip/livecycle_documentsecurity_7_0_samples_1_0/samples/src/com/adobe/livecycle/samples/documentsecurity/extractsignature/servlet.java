package com.adobe.livecycle.samples.documentsecurity.extractsignature;

/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2004 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

import com.adobe.service.DataManager;
import com.adobe.service.DataManagerHelper;
import com.adobe.service.DataBuffer;
import com.adobe.service.ConnectionFactory;

import com.adobe.document.pdf.PDFDocument;
import com.adobe.document.pdf.PDFFactory;
import com.adobe.document.pdf.PDFFactoryHelper;
import com.adobe.document.pdf.SignatureField;
import com.adobe.document.pdf.SignatureInfo;

import com.adobe.livecycle.samples.SessionTempFile;

import javax.rmi.PortableRemoteObject;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.transaction.UserTransaction;

import java.io.IOException;
import java.io.OutputStream;
import java.io.FileOutputStream;

import java.net.URL;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletException;
import javax.servlet.ServletContext;
import javax.servlet.RequestDispatcher;

public class servlet extends HttpServlet
{

  public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
  {

    //
    // Get the web context path for this sample
    //

    String samplePath = request.getServletPath();
    samplePath = samplePath.substring(0, samplePath.lastIndexOf("/"));
    try
    {                 /* START */
      Object o;
      ConnectionFactory connectionFactory;
      InitialContext namingContext = new InitialContext();

      //
      // Start a transaction so the server will know when it can clean
      // up after itself.
      //

      UserTransaction transaction = (UserTransaction) namingContext.lookup
        ("java:comp/UserTransaction");
      transaction.begin();
      try
      {
        //
        // Create PDF manipulation object. We will use this object
        // to extract the signature from a PDF document.
        //

        o = namingContext.lookup("PDFManipulation");
        connectionFactory = (ConnectionFactory) PortableRemoteObject.narrow
          (o,ConnectionFactory.class);
        PDFFactory pdfFactory = PDFFactoryHelper.narrow
          ((org.omg.CORBA.Object)connectionFactory.getConnection());

        //
        // Create a data manager object. The data manager creates the
        // objects that we need to pass to the PDF manipulation object.
        //

        o = namingContext.lookup("DataManagerService");
        connectionFactory = (ConnectionFactory) PortableRemoteObject.narrow
          (o,ConnectionFactory.class);
        DataManager dataManager = DataManagerHelper.narrow
          ((org.omg.CORBA.Object)connectionFactory.getConnection());

        //
        // Read the PDF document into the DataBuffer that we need for
        // the PDF manipulation object to work with.
        //

        String contentUrl =
          request.getScheme() + "://" +
          request.getServerName() + ":" +
          request.getServerPort() +
          request.getContextPath() +
          "/extractsignature/signed.pdf";
        DataBuffer pdfFile = dataManager.createFileDataBufferFromUrl(contentUrl);
        PDFDocument pdfDoc = pdfFactory.openPDF(pdfFile);

        //
        // Extract signature from the PDF document.
        //

        SignatureField [] signatureFieldList = pdfDoc.getSignatureFieldList();
        SignatureField signatureField = signatureFieldList[0];
        SignatureInfo signatureInfo = signatureField.getSignatureInfo();
        byte[] certificate = signatureInfo.certHierarchy[0];

        //
        // Here we create a temporary file in the form of a SessionTempFile.
        // The SessionTempFile object creates a temporary file and
        // implements a session listener to erase the file when the
        // session terminates. The temporary file will hold the extracted
        // certificate so we can refer to it from the next page.
        //

        HttpSession session = request.getSession();
        SessionTempFile stf = new SessionTempFile("step1", ".cer");
        session.setAttribute(samplePath + "/step1.cer", stf);
        OutputStream os = new FileOutputStream(stf.getFile());
        os.write(certificate);
        os.close();
      }
      catch (Exception error)
      {
        //
        // terminate the transaction when there is an exception
        //
        transaction.rollback();
        throw error;
      }

      //
      // Let the server clean up its temporary storage.
      //

      transaction.commit();

      //
      // Redirect the browser to the next page.
      //

      response.sendRedirect("finished.jsp");
      return;
    }               /* STOP */
    catch (Exception error)
    {

      //
      // If we encounter any unexpected errors, forward the server
      // to  an error notification page where we can display the error
      // and a stack trace. This will save you having to search through
      // server log files to find out what went wrong when you start
      // to experiment with this code.
      //

      request.setAttribute("error", error);
      ServletContext context = getServletContext();
      RequestDispatcher dispatcher =
        context.getRequestDispatcher("/common/error.jsp");
      dispatcher.forward(request, response);
      return;
    }
  }
}
