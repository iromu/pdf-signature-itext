package com.adobe.livecycle.samples;

import java.io.File;
import java.io.IOException;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpSessionBindingEvent;

public class SessionTempFile implements HttpSessionBindingListener
{
  private File file;
  private String mimeType;

  public SessionTempFile(String prefix, String suffix) throws IOException
  {
  this.file = File.createTempFile(prefix, suffix);
  if (suffix.equals(".pdf"))
  {
    mimeType = "application/pdf";
  }
  else if (suffix.equals(".xml"))
  {
    mimeType = "text/xml";
  }
  else if (suffix.equals(".html"))
  {
    mimeType = "text/html";
  }
  else if (suffix.equals(".cer"))
  {
    mimeType="application/x-x509-ca-cert";
  }
  else
  {
    mimeType="text/plain";
  }

  }

  public String getContentType()
  {
    return mimeType;
  }

  public void setContentType(String mimeType)
  {
  }

  public File getFile()
  {
  return this.file;
  }

  public void valueBound(HttpSessionBindingEvent event)
  {
  }

  public void valueUnbound(HttpSessionBindingEvent event)
  {
  boolean result = file.delete();
  }
}

