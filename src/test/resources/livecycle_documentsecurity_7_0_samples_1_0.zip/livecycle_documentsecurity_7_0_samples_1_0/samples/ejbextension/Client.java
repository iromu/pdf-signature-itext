package com.adobe.livecycle.samples.simple.documentsecurity.ejbextension;

/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2005 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/
/* START */
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class Client
{
  public void go()
  {
    try
    {
      Hashtable env = new Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY,
        "org.jnp.interfaces.NamingContextFactory");
      env.put(Context.URL_PKG_PREFIXES,
        "org.jboss.naming:org.jnp.interfaces");
      env.put(Context.PROVIDER_URL,
        "jnp://localhost:1099");
      Context ic = new InitialContext(env);
      Object o = ic.lookup("ejb/ValidatePdf");
      ValidatePdfHome home = (ValidatePdfHome)
        PortableRemoteObject.narrow(o, ValidatePdfHome.class);
      ValidatePdf validatePdf = home.create();
      System.out.println(validatePdf.validate
        ("http://localhost:8080/adobe/livecycle/samples/" +
         "simple/documentsecurity/ejbextension/signed.pdf"));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public static void main(String[] args)
  {
    new Client().go();
  }
}
