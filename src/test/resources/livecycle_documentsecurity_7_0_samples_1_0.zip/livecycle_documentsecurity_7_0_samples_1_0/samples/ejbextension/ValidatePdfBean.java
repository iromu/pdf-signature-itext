package com.adobe.livecycle.samples.simple.documentsecurity.ejbextension;

/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2005 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/
/* START */
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import javax.transaction.UserTransaction;

import com.adobe.document.pdf.NotSigned;
import com.adobe.document.pdf.PDFDocument;
import com.adobe.document.pdf.PDFFactory;
import com.adobe.document.pdf.PDFFactoryHelper;
import com.adobe.document.pdf.SignatureField;
import com.adobe.document.pdf.SignatureFieldStatus;
import com.adobe.document.pdf.SignatureInfo;
import com.adobe.service.ConnectionFactory;
import com.adobe.service.DataBuffer;
import com.adobe.service.DataManager;
import com.adobe.service.DataManagerHelper;

public class ValidatePdfBean implements SessionBean
{
  public void ejbActivate()
  {
    System.out.println("EJB activate");
  }
  
  public void ejbPassivate()
  {
    System.out.println("EJB passivate");
  }
  
  public void ejbRemove()
  {
    System.out.println("EJB remove");
  }
  
  public void setSessionContext(SessionContext context)
  {
    System.out.println("set session context");
  }
  
  public void ejbCreate()
  {
    System.out.println("EJB create");
  }
  
  public String validate(String url)
  {
    StringBuffer result = new StringBuffer();
    try
    {
      Object o;
      ConnectionFactory connectionFactory;
      InitialContext namingContext = new InitialContext();

      //
      // Start a transaction so the server will know when it can clean
      // up after itself.
      //

      UserTransaction transaction = (UserTransaction) namingContext.lookup
        ("java:comp/UserTransaction");
      transaction.begin();

      try
      {
        //
        // Create PDF manipulation object. We will use this object
        // to extract and validate signatures.
        //

        o = namingContext.lookup("PDFManipulation");
        connectionFactory = (ConnectionFactory) PortableRemoteObject.narrow
          (o,ConnectionFactory.class);
        PDFFactory pdfFactory = PDFFactoryHelper.narrow
          ((org.omg.CORBA.Object)connectionFactory.getConnection());

        //
        // Create a data manager object. The data manager creates the
        // objects that we need to pass to the PDF manipulation object.
        //

        o = namingContext.lookup("DataManagerService");
        connectionFactory = (ConnectionFactory) PortableRemoteObject.narrow
          (o,ConnectionFactory.class);
        DataManager dataManager = DataManagerHelper.narrow
          ((org.omg.CORBA.Object)connectionFactory.getConnection());

        //
        // Read the PDF document into the DataBuffer that we need for
        // the PDF manipulation object to work with. We get the PDF
        // document using a URL.
        //

        DataBuffer pdfFile = dataManager.
          createFileDataBufferFromUrl(url);
        PDFDocument pdfDoc = pdfFactory.openPDF(pdfFile);

        //
        // Extract the signature field info for all signature fields
        // in the document and capture the results of the validation
        // that is automatically done when the field is extracted.
        //

        SignatureField[] signatureFields = pdfDoc.getSignatureFieldList();
        for (int i = 0; i < signatureFields.length; i++)
        {
          String fieldName = signatureFields[i].getFieldName();
          String signer;
          String signatureStatus;
          try
          {
            SignatureInfo signatureInfo = signatureFields[i].getSignatureInfo();
            signer = signatureInfo.signer;
            SignatureFieldStatus status = signatureInfo.status;
            if (status == SignatureFieldStatus.VALID_SIGNATURE)
              signatureStatus = "VALID_SIGNATURE";
            else
              if (status == SignatureFieldStatus.INVALID_SIGNATURE)
                signatureStatus = "INVALID_SIGNATURE";
              else
                if (status == SignatureFieldStatus.IDENTITY_UNVERIFIABLE)
                  signatureStatus = "IDENTITY_UNVERIFIABLE";
                else
                  if (status == SignatureFieldStatus.STATUS_UNKNOWN)
                    signatureStatus = "STATUS_UNKNOWN";
                  else
                    signatureStatus="Not defined";
          }
          catch (NotSigned error)
          {
            signer = "Not signed";
            signatureStatus = "";
          }
          result.append("Field=" + fieldName + "\n");
          result.append("Signer=" + signer + "\n");
          result.append("Status=" + signatureStatus + "\n");
          result.append("\n");
        }
      }
      catch (Exception error)
      {

        //
        // terminate the transaction when there is an exception
        //

        transaction.rollback();
        throw error;
      }

      //
      // Let the server clean up its temporary storage.
      //

      transaction.commit();


      //
      // Return the results
      //

      return result.toString();

    }
    catch (Exception error)
    {
      return error.toString();
    }
    
  }
}
